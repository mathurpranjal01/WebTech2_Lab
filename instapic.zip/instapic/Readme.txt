-> It's a Website like Instagram Social Media.
Some Features:-
1) You can share pictures on the feed.
2) You can apply filters.
3) Have a recommendation system of Genre.
4) Have a photo feed where you can see your posts and your friends post.
5) Have a nice interface.

